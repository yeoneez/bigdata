from bs4 import BeautifulSoup
from matplotlib import font_manager as fm, rc
from konlpy.tag import Okt
from collections import Counter
from wordcloud import WordCloud

import pytagcloud
import matplotlib.pyplot as plt
import requests
import pandas as pd
import folium, os, re, json
from myProject03.settings import TEMPLATE_DIR, STATIC_DIR
import urllib.parse
import urllib.request

import geopandas as gpd

#naver

clientId = "x7yrxlqoJpTGJZZ_IsGZ"
clientSecret = "MSyKcAAbNd"

def getRequestUrl(url):
    req = urllib.request.Request(url)

    req.add_header("X-Naver-Client-Id", clientId)
    req.add_header("X-Naver-Client-Secret", clientSecret)
    try:
        response = urllib.request.urlopen(req)
        if response.getcode() == 200 :
            return response.read().decode('utf-8')
    
    except:
        return None


def getNaverSearch(node, srcText, start, display):
    base = 'https://openapi.naver.com/v1/search'
    node = '/news.json'
    parameters = "?query=%s&start=%s&display=%s" %(urllib.parse.quote(srcText),start,display)
    url = base+node+parameters

    responseDecode = getRequestUrl(url)
    # print(responseDecode)
    if responseDecode == None :
        return None
    else :
        return json.loads(responseDecode) #loads(): json문자열을 python 객체

def getPostData(post, jsonResult, cnt):
    title = post['title']
    description = post['description']
    originallink = post['originallink']
    link = post['link']
    pubDate = post['pubDate']

    jsonResult.append({'cnt' : cnt, 'title' : title,
                        'description' : description,
                        'originallink' : originallink,
                        'link' : link,
                        'pubDate' : pubDate})

def naver():
    node = 'news'
    srcText = '선거'
    cnt =0
    jsonResult = []

    jsonResponse = getNaverSearch(node, srcText, 1, 100)
    total = jsonResponse['total']

    while((jsonResponse!=None)and(jsonResponse['display'] !=0)):
        for post in jsonResponse['items']:
            cnt += 1
            getPostData(post, jsonResult, cnt)

        start = jsonResponse['start']+jsonResponse['display'] #start = 1 , display = 100
        jsonResponse = getNaverSearch(node, srcText, start, 10)

    #파일로 출력
    with open (STATIC_DIR + '\\data\\%s_naver_%s.json' %(srcText,node), 'w', encoding='utf-8-sig') as outfile:
        jsonFile = json.dumps(jsonResult, indent=4, sort_keys=True, ensure_ascii=False)
        outfile.write(jsonFile)

    a_path = os.path.join(STATIC_DIR, 'data\\선거_naver_news.json')

    data = json.loads(open(a_path, 'r', encoding='utf-8-sig').read())
    title = ''

    for item in data:
        if 'title' in item.keys():
            title = title + re.sub(r'[^\w]', '', item['title'])

    nlp = Okt()

    message_N = nlp.nouns(title)
    count = Counter(message_N)

    word_count = dict()
    #print(count.most_common(5))
    
    for tag, counts in count.most_common(80):
        
        if(len(str(tag))) > 1 :
            word_count[tag] = counts

    font_path = "C:/windows/fonts/malgun.ttf"
    wc = WordCloud(font_path, background_color = 'ivory', width=800, height=800)

    cloud = wc.generate_from_frequencies(word_count)

    plt.figure(figsize=(8,8))
    plt.imshow(cloud)
    plt.axis('off')
    cloud.to_file('./static/images/n_wordCloud.png')






def weather_chart(result, wf, dcounts):
    font_location = "c:/Windows/fonts/malgun.ttf"
    font_name = fm.FontProperties(fname=font_location).get_name()
    plt.rc('font', family=font_name)
    print(wf)

    high = []
    low = []
    xdata = []

    for r in result.values_list():
        high.append(r[5])
        low.append(r[4])
        xdata.append(r[2])

    plt.figure(figsize=(10,6))
    plt.xticks(range(len(xdata)), list(xdata), rotation=30, fontsize=8)
    plt.plot(xdata, low, label='최저기온')
    plt.plot(xdata, high, label='최고기온')
    plt.legend()
    plt.savefig(os.path.join(STATIC_DIR, 'images\\weather_plot.png'), dpi=300)
    plt.cla()  

    image_dic = {'plot': 'weather_plot.png'}

    # 막대그래프
    plt.figure(figsize=(10,6))
    plt.bar(wf, dcounts)
    plt.savefig(os.path.join(STATIC_DIR, 'images\\weather_bar.png'), dpi=300)
    plt.cla()

    image_dic = {'plot': 'weather_plot.png',
                        'bar':'weather_bar.png'}

    # 파이차트
    plt.figure(figsize=(10,6))
    plt.pie(dcounts, labels=wf, autopct='%.1f%%')
    plt.savefig(os.path.join(STATIC_DIR, 'images\\weather_pie.png'), dpi=300)
    plt.close()  

    image_dic = {'plot': 'weather_plot.png',
                'bar':'weather_bar.png',
                'pie' : 'weather_pie.png'}
    # print(image_dic)

    return image_dic



def weather_crawling(last_date, weather):
    
    req = requests.get('https://www.weather.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=108')

    soup = BeautifulSoup(req.text, 'lxml')

    # print(soup)

    for i in soup.find_all('location'):
        weather[i.find('city').text] = []

        for j in i.find_all('data'):
        
            temp = []

            if((len(last_date) == 0) or (j.find('tmef').text > last_date[0]['tmef']) ):

                temp.append(j.find('tmef').text)
                temp.append(j.find('wf').text)
                temp.append(j.find('tmn').text)
                temp.append(j.find('tmx').text)
                
                weather[i.find('city').string].append(temp)

            # print('temp: ', temp)

    # print(weather)

    return weather


def make_wordCloud():

    s = '좋은 아침이에요. 안녕하세요'
    m = re.search('안녕', s)
    print(m)

    a_path = os.path.join(STATIC_DIR, 'data\\4차 산업혁명.json')

    data = json.loads(open(a_path, 'r', encoding='utf-8').read())
    
    message = ''

    for item in data:
        if 'message' in item.keys():
            message = message + re.sub(r'[^\w]', '', item['message'])

    nlp = Okt()

    message_N = nlp.nouns(message)
    count = Counter(message_N)

    word_count = dict()
    #print(count.most_common(5))
    
    for tag, counts in count.most_common(80):
        
        if(len(str(tag))) > 1 :
            word_count[tag] = counts

    font_path = "C:/windows/fonts/malgun.ttf"
    wc = WordCloud(font_path, background_color = 'ivory', width=800, height=800)

    cloud = wc.generate_from_frequencies(word_count)

    plt.figure(figsize=(8,8))
    plt.imshow(cloud)
    plt.axis('off')
    cloud.to_file('./static/images/k_wordCloud.png')

#map
def map():

    ex = {'경도' : [127.061026,127.047883,127.899220,128.980455,127.104071,127.102490,127.088387,126.809957,127.010861,126.836078
                ,127.014217,126.886859,127.031702,126.880898,127.028726,126.897710,126.910288,127.043189,127.071184,127.076812
                ,127.045022,126.982419,126.840285,127.115873,126.885320,127.078464,127.057100,127.020945,129.068324,129.059574
                ,126.927655,127.034302,129.106330,126.980242,126.945099,129.034599,127.054649,127.019556,127.053198,127.031005
                ,127.058560,127.078519,127.056141,129.034605,126.888485,129.070117,127.057746,126.929288,127.054163,129.060972],
        '위도' : [37.493922,37.505675,37.471711,35.159774,37.500249,37.515149,37.549245,37.562013,37.552153,37.538927,37.492388
                ,37.480390,37.588485,37.504067,37.608392,37.503693,37.579029,37.580073,37.552103,37.545461,37.580196,37.562274
                ,37.535419,37.527477,37.526139,37.648247,37.512939,37.517574,35.202902,35.144776,37.499229,35.150069,35.141176
                ,37.479403,37.512569,35.123196,37.546718,37.553668,37.488742,37.493653,37.498462,37.556602,37.544180,35.111532
                ,37.508058,35.085777,37.546103,37.483899,37.489299,35.143421],
        '구분' : ['음식','음식','음식','음식','생활서비스','음식','음식','음식','음식','음식','음식','음식','음식','음식','음식'
                ,'음식','음식','소매','음식','음식','음식','음식','소매','음식','소매','음식','음식','음식','음식','음식','음식'
                ,'음식','음식','음식','음식','소매','음식','음식','의료','음식','음식','음식','소매','음식','음식','음식','음식'
                ,'음식','음식','음식']}
    
    ex = pd.DataFrame(ex)

    print(ex)

    lat = ex['위도'].mean()
    long = ex['경도'].mean()

    #지도 띄우기
    m = folium.Map([lat,long], zoom_start=9, tiles="OpenStreetMap")

    print(ex.index)

    for i in ex.index:

        sub_lat = ex.loc[i, '위도']
        sub_long = ex.loc[i, '경도']

        title = ex.loc[i, '구분']

        folium.Marker(location=[sub_lat, sub_long], tooltip=title).add_to(m)

        m.save(os.path.join(TEMPLATE_DIR, 'bigdata/maptest.html'))

    
    

#melon
def melon_crawling(datas):
    # req = requests.get('https://www.naver.com/')
    header = {'User-Agent' : 'Mozilla/5.0'}
    req = requests.get('https://www.melon.com/chart/index.htm', headers=header)
    soup  = BeautifulSoup(req.text, 'html.parser')
    # 순위 곡명 가수 앨범 ==> 추출해서  datas에 10곡만   append 시키기
    #frm > div > table > tbody
    tbody = soup.select_one('#frm > div > table > tbody')
    
    #lst50
    trs = tbody.select('#lst50')
    print(trs)
    for tr in trs[:10]:
        #lst50 > td:nth-child(2) > div > span.rank
        rank = tr.select_one('span.rank').string
        #lst50 > td:nth-child(6) > div > div > div.ellipsis.rank01 > span > a
        song = tr.select_one('div.ellipsis.rank01 > span > a').string
        #lst50 > td:nth-child(6) > div > div > div.ellipsis.rank02 > a
        singer = tr.select_one('div.ellipsis.rank02 > a').string
        #lst50 > td:nth-child(7) > div > div > div > a
        album = tr.select_one('div.ellipsis.rank03 > a').string
        # datas.append([rank, song, singer, album]) # 리스트 append
        tmp  = dict()
        tmp['rank'] = rank
        tmp['song'] = song
        tmp['singer'] = singer
        tmp['album'] = album
        datas.append(tmp)  # dict append
    # print('datas : ', datas)


def movie(datas):
    # req = requests.get('https://www.naver.com/')
    header = {'User-Agent' : 'Mozilla/5.0'}
    req = requests.get('http://www.cgv.co.kr/movies/?lt=1&ft=0', headers=header)
    soup  = BeautifulSoup(req.text, 'html.parser')

    # print(soup)

    tbody = soup.select_one('.sect-movie-chart')
#  > #contents > .inner-wrap > .movie-list > ol > li > .no-image
    # print(tbody)

    rank = tbody.select("strong.rank")
    movie = tbody.select("strong.title")
    percent = tbody.select("span.percent")

    date = tbody.select("span.txt-info > strong")

    print(date[0])

    for i in range(0, 10):

        tmp = dict()

        tmp['rank'] = rank[i].text
        tmp['movie'] = movie[i].text
        tmp['percent'] = percent[i].text
        tmp['date'] = date[i].text

        datas.append(tmp)
    
    # print('datas : ', datas)

def movie_crawling(movie):
    header={'User-Agent':'Mozilla/5.0 '}
    req = requests.get('http://www.cgv.co.kr/movies/?lt=1&ft=0',headers=header)
    soup=BeautifulSoup(req.text,'html.parser')
   #contents > div.wrap-movie-chart > div.sect-movie-chart
    sect=soup.select_one('#contents > div.wrap-movie-chart > div.sect-movie-chart')
    #contents > div.wrap-movie-chart > div.sect-movie-chart > ol:nth-child(2)

    # ols=sect.select('ol')
    #contents > div.wrap-movie-chart > div.sect-movie-chart > ol:nth-child(2) > li:nth-child(1)
    
    lis=sect.select('li')
    # print('lis :' , lis)
    for li in lis[:10]:
        
        rank=li.select_one('strong.rank').string
        title=li.select_one('strong.title').string
        #contents > div.wrap-movie-chart > div.sect-movie-chart > ol:nth-child(2) > li:nth-child(1) > div.box-contents > span.txt-info > strong > span
        #contents > div.wrap-movie-chart > div.sect-movie-chart > ol:nth-child(2) > li:nth-child(1) > div.box-contents > span.txt-info > strong
        realese=li.select_one('div.box-contents > span.txt-info > strong').get_text()
        realese = realese.strip()[:10]
        #contents > div.wrap-movie-chart > div.sect-movie-chart > ol:nth-child(2) > li:nth-child(1) > div.box-contents > div > strong > span
        reservation=li.select_one('div.box-contents > div > strong > span').string
        #contents > div.wrap-movie-chart > div.sect-movie-chart > ol:nth-child(2) > li:nth-child(1) > div.box-contents > div > div > span.percent
        egg=li.select_one( 'div.box-contents > div > div > span.percent').string
        # movie.append([rank,title,realese,reservation,egg])    #리스트 append

        tmp=dict()
        tmp['rank']=rank
        tmp['title']=title
        tmp['realese']=realese
        tmp['reservation']=reservation
        tmp['egg']=egg
        movie.append(tmp)   

        
    print('movie:',movie)

#movie_chart
def cgv_movie_chart(title, points):
    font_location="c:/Windows/fonts/malgun.ttf"
    font_name=fm.FontProperties(fname=font_location).get_name()
    plt.rc('font', family = font_name)
    plt.cla()
    plt.ylabel('영화평점')
    # plt.xlabel('영화제목')
    plt.title('Top 10 영화')
    plt.bar(range(len(title)), points, align='center')
    plt.xticks(range(len(title)), list(title), rotation=5, fontsize=5)
    plt.savefig(os.path.join(STATIC_DIR, 'images\\cgv_movie_char1.png'), dpi=300)

#make_wordCloud2
def make_wordCloud2():
    #4차 산업혁명 파일 불러오기
    a_path = os.path.join(STATIC_DIR, 'data\\4차산업혁명.json')
    data = json.loads(open(a_path, 'r', encoding='utf-8').read())

    message = ''
    for item in data:
        if 'message' in item.keys():
            message = message + re.sub(r'[^\w]', '', item['message'])+''
    nlp = Okt()
    message_N = nlp.nouns(message) #명사추출
    count = Counter(message_N)
    word_dit = dict()
    for tag, counts in count.most_common(80):
        if(len(str(tag))>1) :
            word_dit[tag] = counts
            print('%s : %d' %(tag, counts))
    # font_path = "c:/Windows/fonts/malgun.ttf"
    taglist = pytagcloud.make_tags(word_dit.items(), maxsize=80)
    pytagcloud.crate_tag_image(taglist,
                               './static/images/k_wordCloud2.png',
                               size=(600,500),
                               fontname= 'Korean',
                               rectangular=False)
    

