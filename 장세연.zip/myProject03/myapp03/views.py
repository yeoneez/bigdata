from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Q
from django.core.paginator import Paginator

from django.views.decorators.csrf import csrf_exempt
from .form import UserForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from myapp03 import dataProcess
from myapp03.models import Board,Comment,Forecast
from django.db.models.aggregates import Count,Avg
import pandas as pd
# Create your views here.
UPLOAD_DIR = 'C:/DJANGOWORK/upload/'

####### bigdata

#naver
def naver(request):
    dataProcess.naver()
    return render(request, 'bigdata/naver.html',
                  {'img_data' :'n_wordCloud.png'})


# weather
def weather(request):
    last_date = Forecast.objects.values('tmef').order_by('-tmef')[:1]
    # print('last_date query :' , last_date.query)  # 생성된  sql문 확인
    weather = {}
    dataProcess.weather_crawling(last_date,weather)
    for i in weather:
        for j in weather[i]:
            dto = Forecast(city = i,
                           tmef= j[0],
                           wf = j[1],
                           tmn = j[2],
                           tmx = j[3])
            dto.save()
    # 부산 정보만 출력
    result = Forecast.objects.filter(city='부산')    
    result1 = Forecast.objects.filter(city='부산').values('wf').annotate(dcount=Count('wf')).values('dcount','wf')    
    # print('result1 query : ', result1.query)
    df = pd.DataFrame(result1)
    # print('df : ', df)
    image_dic = dataProcess.weather_chart(result, df.wf, df.dcount)
    return render(request, 'bigdata/chart.html',
                  {'img_data' : image_dic })



# wordcloud
def wordcloud(request):
    dataProcess.make_wordCloud()
    return render(request,'bigdata/word.html',
                  {'img_data':'k_wordCloud.png'})

# wordcloud2
def wordcloud2(request):
    dataProcess.make_wordCloud2()
    return render(request,'bigdata/word.html',
                  {'img_data':'k_wordCloud2.png'})

#cgv_movie
def cgv_movie(request):
    movie=[]
    dataProcess.movie_crawling(movie)

    return render(request,'bigdata/movie.html',
                  {'movie':movie})
#cgv
def cgv(request):
    data = [] 
    # data = dataProcess.cgv_movie_crawling(data)
    data = dataProcess.movie_crawling(data)  # 김민주
   
    # print(data)
    df = pd.DataFrame(data, columns=['제목','예매율','평점'])
    print('df : ', df)
    group_title = df.groupby('제목')
    # print(group_title)
   
    # 제목별 그룹화 해서 평점의 평균
    group_mean = df.groupby('제목')['평점'].mean().sort_values(ascending=False).head(10)
    # print(group_mean)
    df1 = pd.DataFrame(group_mean, columns=['평점'])
    print(df1)
    dataProcess.cgv_movie_chart(df1.index, df1.평점)

    return render(request, 'bigdata/cgv.html', 
                  {'img_data' : 'cgv_movie_chart1.png'})


# melon
def melon(request):
    # 순위 곡명 가수 앨범
    datas = []
    dataProcess.melon_crawling(datas)

    return render(request, 'bigdata/melon.html',
                  {'datas':datas})

    # return render(request, 'bigdata/melon_list.html',
    #               {'datas':datas})

# map
def map(request):
    dataProcess.map()
    return render(request, 'bigdata/map.html')



# comment insert
@csrf_exempt
@login_required(login_url='/login/')
def comment_insert(request):
    board_id = request.POST['id']
    board = get_object_or_404(Board, pk=board_id)
    dto = Comment(
        writer = request.user,
        content = request.POST['content'],
        board = board
    )
    dto.save()
  # return redirect('/detail_id?id="+board_id)
    return redirect('/detail/'+board_id)

# delete
def delete(request,board_id):
    Board.objects.get(id=board_id).delete()

    return redirect('/list')

#  수정 폼
def update_form(request,board_id):
    dto = Board.objects.get(id=board_id)

    return render(request, 'board/update.html'
                  ,{'board':dto})

# 수정
@csrf_exempt
def update(request):
    id = request.POST['id']
    dto = Board.objects.get(id=id)
    fname = dto.filename
    fsize = dto.filesize
    ### file  수정
    if 'file' in request.FILES:
        file = request.FILES['file']
        fsize = file.size
        fname = file.name

        fp = open('%s%s' %(UPLOAD_DIR,fname),'wb')

        for chunk in file.chunks():
            fp.write(chunk)
        fp.close() 

    dto_update =Board(id, 
                      writer =request.user,
                      title = request.POST['title'],
                      content = request.POST['content'],
                      filename = fname,
                      filesize = fsize)  
    dto_update.save() 
    return redirect('/list')


    return redirect('/list')




##############
# write_form
@login_required(login_url='/login/')
def write_form(request):
    return render(request, 'board/insert.html')

#insert
@csrf_exempt
def insert(request):
    #파일처리
    fname = ''
    fsize = 0
    if 'file' in request.FILES:
        file = request.FILES['file']
        fname = file.name
        fsize = file.size
        fp = open('%s%s' %(UPLOAD_DIR ,fname),'wb')
        for chunk in file.chunks():
            fp.write(chunk)
        fp.close()    
        
    board = Board(writer=request.user,
                  title = request.POST['title'],
                  content=request.POST['content'],
                  filename=fname,
                  filesize=fsize)
    board.save()
    return redirect('/list/')

# list (Paginator 이용)
def list(request):
    page = request.GET.get('page',1)
    word = request.GET.get('word','')
    print('word : ', word)

    boardCount = Board.objects.filter(Q(title__contains=word)|
                                      Q(content__contains=word)|
                                      Q(writer__username__contains=word)).count() 
    boardList= Board.objects.filter(Q(title__contains=word)|
                                    Q(content__contains=word)|
                                    Q(writer__username__icontains=word)).order_by('-id')
                                    #icontains 대소문자 무시

    pageSize = 5
    # 페이징처리
    paginater = Paginator(boardList, pageSize) 
    page_obj = paginater.get_page(page)
    rowNo = boardCount-(int(page)-1)*pageSize 

    context = {'page_list' : page_obj,
               'page' : page,
               'word' : word,
               'rowNo': rowNo,
               'boardCount':boardCount  }
    return render(request, 'board/list.html', context)

#signup
def signup(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            print('signup POST valid') 
            form.save()     
            username = form.cleaned_data.get('username')
            raw_password = form.changed_data.get('password')
            user = authenticate(username=username, password=raw_password)   #import
            login(request, user)  #import
            return redirect('/')
        else:
          print('signup POST un_valid')      
    else:
        form = UserForm()    
    return render(request, 'common/signup.html', {'form' : form})

# detail
def detail(request,board_id):
    dto = Board.objects.get(id=board_id)
    dto.hit_up()
    dto.save()

    return render(request,'board/detail.html',
                  {'board':dto})




